package com.neeshai.backend.kb;

import java.time.ZonedDateTime;
import java.util.UUID;

public record KnowledgeDocumentDTO(
        UUID id,
        UUID documentGroupId,
        UUID projectId,
        String filename, // original_filename
        String mimeType,
        int version,
        ZonedDateTime uploadedAt) {
    public static KnowledgeDocumentDTO fromEntity(Document doc) {
        return new KnowledgeDocumentDTO(
                doc.getId(),
                doc.getDocumentGroupId(),
                doc.getProjectId(),
                doc.getOriginalFilename(),
                doc.getMimeType(),
                doc.getVersion(),
                doc.getCreatedAt());
    }
}
