package com.neeshai.backend.blog;

import java.util.List;

public class BlogDTOs {

    public record CustomField(
            String id,
            String type,
            String value,
            int order) {
    }

    public record BlogContentDTO(
            String heading,
            String coverImageUrl,
            String introduction,
            String content,
            List<CustomField> customFields) {
    }

    public record UpdateBlogRequest(
            String heading,
            String coverImageUrl,
            String introduction,
            String content,
            List<CustomField> customFields) {
    }
}
