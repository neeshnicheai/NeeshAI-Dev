package com.neeshai.backend.user;

import java.time.ZonedDateTime;
import java.util.UUID;

public record UserDTO(
        UUID id,
        String email,
        String name,
        String status,
        ZonedDateTime createdAt,
        ZonedDateTime updatedAt) {
    public static UserDTO fromEntity(User user) {
        return new UserDTO(
                user.getId(),
                user.getEmail(),
                user.getName(),
                user.getStatus(),
                user.getCreatedAt(),
                user.getUpdatedAt());
    }
}
