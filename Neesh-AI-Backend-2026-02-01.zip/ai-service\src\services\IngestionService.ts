import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { ChunkingService } from './ChunkingService';
import { EmbeddingService } from './EmbeddingService';
import { VectorStoreService } from './VectorStoreService';

export class IngestionService {
    private supabase: SupabaseClient;
    private chunkingService: ChunkingService;
    private embeddingService: EmbeddingService;
    private vectorStore: VectorStoreService;

    constructor() {
        const sbUrl = process.env.SUPABASE_URL;
        const sbKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
        if (!sbUrl || !sbKey) throw new Error("SUPABASE env vars missing");

        this.supabase = createClient(sbUrl, sbKey);
        this.chunkingService = new ChunkingService();
        this.embeddingService = new EmbeddingService();
        this.vectorStore = new VectorStoreService();
    }

    async ingestProject(projectId: string): Promise<void> {
        console.log(`Starting ingestion for project ${projectId}`);

        // 1. Fetch Active Documents
        const { data: documents, error } = await this.supabase
            .from('documents')
            .select('*')
            .eq('project_id', projectId)
            .eq('is_active', true);

        if (error || !documents) {
            throw new Error("Failed to fetch documents");
        }

        console.log(`Found ${documents.length} active documents to index.`);

        for (const doc of documents) {
            try {
                console.log(`Processing doc: ${doc.original_filename} (v${doc.version})`);

                // 2. Fetch Content (Simulated download from Storage)
                // In real world: Use storageService to downloadBytes(doc.storage_path)
                // Here we simulate content based on filename for MVP unless we integrate PDF parser
                // Let's assume content is just metadata + placeholder for this Step.
                // OR better: Since we don't have real file content, we use a placeholder text.
                // "This is the content of document [filename]."
                const content = `[Content of ${doc.original_filename}]\nThis is a placeholder for the actual file content which would be downloaded from ${doc.storage_path} and parsed (PDF/DOCX).`;

                // 3. Chunk
                const chunks = await this.chunkingService.chunkText(content);

                // 4. Embed
                const embeddings = await this.embeddingService.generateEmbeddings(chunks);

                // 5. Store (Idempotent: deactivates old)
                await this.vectorStore.storeVectors(
                    projectId,
                    doc.document_group_id,
                    doc.version,
                    chunks,
                    embeddings
                );

            } catch (err) {
                console.error(`Error processing doc ${doc.id}:`, err);
                // Continue with other docs, but log error
            }
        }

        console.log(`Ingestion complete for project ${projectId}`);
    }
}
