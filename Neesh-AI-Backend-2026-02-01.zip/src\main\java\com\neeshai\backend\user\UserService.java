package com.neeshai.backend.user;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.UUID;

@Service
public class UserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Idempotent sync of user from JWT claims.
     * Logic:
     * 1. If user (by ID) not found -> INSERT
     * 2. If user found -> Check email -> If changed, UPDATE
     * 3. Else -> No Action
     */
    @Transactional
    public void syncUser(UUID id, String email, String name) {
        Optional<User> existingUserOpt = userRepository.findById(id);

        if (existingUserOpt.isEmpty()) {
            // INSERT
            User newUser = new User(id, email, name, "ACTIVE");
            userRepository.save(newUser);
        } else {
            // UPDATE only if needed
            User existingUser = existingUserOpt.get();
            boolean changed = false;

            if (email != null && !email.equals(existingUser.getEmail())) {
                existingUser.setEmail(email);
                changed = true;
            }
            // Optional: Also sync name if it changes from Supabase?
            // Requirement says "If user exists and email changed -> UPDATE", doesn't
            // explicitly mention name.
            // But let's keep name synced too for consistency if provided.
            if (name != null && !name.equals(existingUser.getName())) {
                existingUser.setName(name);
                changed = true;
            }

            if (changed) {
                userRepository.save(existingUser);
            }
        }
    }

    public Optional<UserDTO> getUser(UUID id) {
        return userRepository.findById(id).map(UserDTO::fromEntity);
    }
}
