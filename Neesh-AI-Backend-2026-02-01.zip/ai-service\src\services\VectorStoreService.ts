import { createClient, SupabaseClient } from '@supabase/supabase-js';

export interface QueryResult {
    chunk_text: string;
    document_group_id: string;
    document_version: number;
    chunk_index: number;
    similarity: number;
    source_type?: 'DOCUMENT' | 'MANUAL';
    manual_answer_type?: 'OVERRIDE' | 'SUPPLEMENT';
}

export interface VectorMetadata {
    source_type: 'DOCUMENT' | 'MANUAL';
    manual_answer_type?: 'OVERRIDE' | 'SUPPLEMENT';
}

export class VectorStoreService {
    private supabase: SupabaseClient;

    constructor() {
        const sbUrl = process.env.SUPABASE_URL;
        const sbKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
        if (!sbUrl || !sbKey) {
            throw new Error("SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY not set");
        }
        this.supabase = createClient(sbUrl, sbKey);
    }

    async storeVectors(
        projectId: string,
        documentGroupId: string,
        documentVersion: number,
        chunks: string[],
        embeddings: number[][],
        metadata?: VectorMetadata
    ): Promise<void> {

        // 1. Invalidation
        const { error: deactivateError } = await this.supabase
            .from('project_embeddings')
            .update({ is_active: false })
            .eq('project_id', projectId)
            .eq('document_group_id', documentGroupId);

        if (deactivateError) {
            throw new Error(`Failed to invalidate vectors: ${deactivateError.message}`);
        }

        // 2. Prepare Records (Traceable)
        const records = chunks.map((chunk, idx) => ({
            project_id: projectId,
            document_group_id: documentGroupId,
            document_version: documentVersion,
            chunk_index: idx,
            chunk_text: chunk,
            embedding: embeddings[idx],
            is_active: true,
            source_type: metadata?.source_type || 'DOCUMENT',
            manual_answer_type: metadata?.manual_answer_type || null
        }));

        if (records.length === 0) return;

        // 3. Insert New Active Vectors
        const { error: insertError } = await this.supabase
            .from('project_embeddings')
            .insert(records);

        if (insertError) {
            throw new Error(`Failed to insert vectors: ${insertError.message}`);
        }
    }

    async queryVectors(
        projectId: string,
        queryEmbedding: number[],
        topK: number = 5,
        minScore: number = 0.7
    ): Promise<QueryResult[]> {

        const { data, error } = await this.supabase.rpc('match_project_embeddings', {
            query_embedding: queryEmbedding,
            match_threshold: minScore,
            match_count: topK,
            filter_project_id: projectId
        });

        if (error) throw new Error(`Query failed: ${error.message}`);

        return data as QueryResult[];
    }
}
