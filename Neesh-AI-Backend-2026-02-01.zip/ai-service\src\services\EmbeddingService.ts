import { GoogleGenerativeAI } from '@google/generative-ai';

export class EmbeddingService {
    private genAI: GoogleGenerativeAI;
    private model: any;

    constructor() {
        const apiKey = process.env.GEMINI_API_KEY;
        if (!apiKey) {
            throw new Error("GEMINI_API_KEY is not set");
        }
        this.genAI = new GoogleGenerativeAI(apiKey);
        this.model = this.genAI.getGenerativeModel({ model: "embedding-001" }); // or text-embedding-004 if available
    }

    async generateEmbedding(text: string): Promise<number[]> {
        // Replace newlines to minimize embedding distortion
        const cleanText = text.replace(/\n/g, ' ');
        const result = await this.model.embedContent(cleanText);
        const embedding = result.embedding;
        return embedding.values;
    }

    async generateEmbeddings(texts: string[]): Promise<number[][]> {
        // Parallelize or batch? Gemini rate limits might apply.
        // Sequential for safety in this MVP step.
        const embeddings: number[][] = [];
        for (const t of texts) {
            embeddings.push(await this.generateEmbedding(t));
        }
        return embeddings;
    }
}
