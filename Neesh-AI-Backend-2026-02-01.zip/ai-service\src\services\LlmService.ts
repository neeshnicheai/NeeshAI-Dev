import { GoogleGenerativeAI } from '@google/generative-ai';
import { FOUNDER_SYSTEM_PROMPT, constructUserPrompt } from '../prompts/SystemPrompts';

export interface GeneratedAnswer {
    answer: string;
    confidence: 'HIGH' | 'MEDIUM' | 'LOW'; // Inferred
}

export class LlmService {
    private genAI: GoogleGenerativeAI;
    private model: any;

    constructor() {
        const apiKey = process.env.GEMINI_API_KEY;
        if (!apiKey) {
            throw new Error("GEMINI_API_KEY is not set");
        }
        this.genAI = new GoogleGenerativeAI(apiKey);
        this.model = this.genAI.getGenerativeModel({ model: "gemini-pro" });
    }

    async generateAnswer(query: string, contextChunks: string[]): Promise<GeneratedAnswer> {
        if (contextChunks.length === 0) {
            return {
                answer: "I don't have enough information in this project to answer that.",
                confidence: 'LOW'
            };
        }

        try {
            // Gemini Pro text generation
            const prompt = constructUserPrompt(query, contextChunks);

            // We send System Prompt logic as part of the first message or "system instruction" if supported.
            // Gemini 1.0 Pro via API often takes system prompt as part of the text.
            // Better approach using chat structure:
            const chat = this.model.startChat({
                history: [
                    {
                        role: "user",
                        parts: [{ text: FOUNDER_SYSTEM_PROMPT }],
                    },
                    {
                        role: "model",
                        parts: [{ text: "Understood. I will answer as the AI Founder using only the provided context." }],
                    },
                ],
                generationConfig: {
                    maxOutputTokens: 500, // Concise
                    temperature: 0.3, // Low temperature for factual grounding
                },
            });

            const result = await chat.sendMessage(prompt);
            const response = await result.response;
            const text = response.text();

            // Heuristic for confidence?
            // For now, if it returns the fallback phrase, low confidence.
            // Otherwise, HIGH (since we filtered chunks before calling this).
            let confidence: 'HIGH' | 'MEDIUM' | 'LOW' = 'HIGH';

            if (text.includes("I don't have enough information") || text.includes("missing")) {
                confidence = 'LOW';
            }

            return {
                answer: text.trim(),
                confidence
            };

        } catch (error) {
            console.error("LLM Generation Error:", error);
            throw new Error("Failed to generate answer");
        }
    }
}
