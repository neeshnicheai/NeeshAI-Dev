import { VectorStoreService, QueryResult } from './VectorStoreService';
import { EmbeddingService } from './EmbeddingService';
import { LlmService } from './LlmService';
import { LearningService } from './LearningService';

export interface ChatResponse {
    answer: string;
    confidence: 'HIGH' | 'MEDIUM' | 'LOW';
    sources: SourceMetadata[];
    questionId: string;
    answerLogId: string;
}

export interface SourceMetadata {
    document_group_id: string;
    document_version: number;
    chunk_index: number;
    similarity_score: number;
    source_type?: 'DOCUMENT' | 'MANUAL'; // Traceability
}

export class ChatService {
    private vectorStore: VectorStoreService;
    private embeddingService: EmbeddingService;
    private llmService: LlmService;
    private learningService: LearningService;

    constructor() {
        this.vectorStore = new VectorStoreService();
        this.embeddingService = new EmbeddingService();
        this.llmService = new LlmService();
        this.learningService = new LearningService();
    }

    async askQuestion(projectId: string, query: string): Promise<ChatResponse> {
        const questionId = await this.learningService.logQuestion(projectId, query);

        // 1. Retrieve
        const queryEmbedding = await this.embeddingService.generateEmbedding(query);
        const chunks = await this.vectorStore.queryVectors(projectId, queryEmbedding, 5, 0.65);

        // 2. Priority Logic (Hardened)

        // Check for OVERRIDE manual answer with high confidence
        const overrideChunk = chunks.find(c =>
            c.source_type === 'MANUAL' &&
            c.manual_answer_type === 'OVERRIDE' &&
            c.similarity >= 0.85 // Strict 
        );

        let answer = "";
        let confidence: 'HIGH' | 'MEDIUM' | 'LOW' = 'LOW';
        let finalSources: SourceMetadata[] = [];
        let isAi = true;

        if (overrideChunk) {
            // FAST TRACK: Use Manual Answer directly
            // Extract answer part from "Question: ... \nAnswer: ..."
            // Or just return the whole chunk text if it's clean enough? 
            // Our injection format is "Question: q\nAnswer: a". 
            // We should try to parse it or just return it. 
            // Founder tone might be preserved in the text itself.

            const text = overrideChunk.chunk_text;
            const answerPart = text.split('Answer:')[1];
            answer = answerPart ? answerPart.trim() : text; // Fallback to full text if parse fails

            confidence = 'HIGH';
            isAi = false; // It's a manual override

            finalSources = [{
                document_group_id: overrideChunk.document_group_id,
                document_version: overrideChunk.document_version,
                chunk_index: overrideChunk.chunk_index,
                similarity_score: overrideChunk.similarity,
                source_type: 'MANUAL'
            }];

        } else {
            // Standard RAG (Supplement + Documents)
            if (chunks.length === 0) {
                answer = "I don't have enough information in this project to answer that.";
                confidence = 'LOW';
            } else {
                confidence = this.calculateConfidence(chunks);
                const contextTexts = chunks.map(c => c.chunk_text);
                const generated = await this.llmService.generateAnswer(query, contextTexts);

                answer = generated.answer;
                if (generated.confidence === 'LOW') confidence = 'LOW';

                finalSources = chunks.map(c => ({
                    document_group_id: c.document_group_id,
                    document_version: c.document_version,
                    chunk_index: c.chunk_index,
                    similarity_score: c.similarity,
                    source_type: c.source_type
                }));
            }
        }

        const logId = await this.learningService.logAnswer(questionId, answer, confidence, isAi);

        return {
            answer,
            confidence,
            sources: finalSources,
            questionId,
            answerLogId: logId
        };
    }

    private calculateConfidence(chunks: QueryResult[]): 'HIGH' | 'MEDIUM' | 'LOW' {
        if (chunks.length === 0) return 'LOW';
        const allHigh = chunks.every(c => c.similarity >= 0.80);
        const countMultiple = chunks.length >= 2;

        if (countMultiple && allHigh) return 'HIGH';
        if (chunks.some(c => c.similarity >= 0.65)) return 'MEDIUM';
        return 'LOW';
    }
}
